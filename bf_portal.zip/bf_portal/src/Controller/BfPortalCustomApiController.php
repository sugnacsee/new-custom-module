<?php
namespace Drupal\bf_portal\Controller;

use Drupal\node\Entity\Node;
use Drupal\Core\Controller\ControllerBase;
//use Drupal\Core\Session\AccountInterface;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Datetime\Entity\DateFormat;

use DateTime;
use DateTimeZone;
use Drupal\group\Entity\Group;

/**
 * Provide custom Json API endpoints.
 */
class BfPortalCustomApiController extends ControllerBase {
  public function getAPI() {
  
    header("Content-Type: application/json");
    
    $client = \Drupal::httpClient();

    
      // $response = \Drupal::httpClient()
      // ->get('https://www.thegazette.co.uk/all-notices/notice/data.json');
      //     $code = $response->getStatusCode();
      // if ($code == 200) {
      //   $response_body = $response->getBody()->getContents();
      //   }
      $client = new \GuzzleHttp\Client();
      $url = 'https://www.thegazette.co.uk/all-notices/notice/data.json';
      $res = $client->request('GET', $url);
      $res_data = $res->getBody();
      $items           = json_decode($res_data, TRUE);

     // $items = [];
  

      // foreach ($data as $d) {
      //   foreach ($d as $ins) {  
      //   $items[] = $ins['id'] ;

      //   }
      // }
    print_r($items);exit;
    return [
        '#theme' => 'page-list',
        '#items' => $items,
        '#title' => $this->t('All Datas to display'),
      ];
  
    }
     
   // return new Response($res_data);
    
  

  public function listData() {
 
    $user = [
      ['name' => 'Eddy'],
      ['name' => 'Nadeem'],
      ['name' => 'Ramesh'],
      ['name' => 'Adam'],
      ['name' => 'Shana']
      
    ];
 
    return [
      '#theme' => 'page-list',
      '#items' => $students,
      '#title' => $this->t('All Datas to display'),
    ];
	

    
   }
}
?>