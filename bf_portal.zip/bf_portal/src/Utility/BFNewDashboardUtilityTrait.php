<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\field\Entity\FieldConfig;
use Drupal\file\Entity\File;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Drupal\paragraphs\Entity\Paragraph;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\workflow\Entity\WorkflowConfigTransition;
use Drupal\workflow\Entity\WorkflowState;
use Drupal\workflow\Entity\Workflow;
use Drupal\workflow\Entity\WorkflowManager;
use Drupal\workflow\Entity\WorkflowTransition;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\Core\Database\Query;

trait BFNewDashboardUtilityTrait
{

  /**
  * Function :: New dashboard with catalogue listings for TL & Designer using loggedin user id and user type.
  */
  public function GetBFDashboardDetailsByParams($requestparams) {
    # Get the DB Connection
		$db 	= \Drupal::database();
    $userID         = (isset($requestparams['userid']) && !empty($requestparams['userid']) && $requestparams['userid']!=null) ? $requestparams['userid']:null;
    // Get user details by user id.
    $GetUserDetails = $this->GetUserDetailsByUserId($userID);
    if($GetUserDetails) {
      $UserClientDetails = $GetUserDetails['user_details']['client_detail'];
      $GetClientId       = $this->GetClientIdByDetails($UserClientDetails);
      // Get Briefing form details.
      $GetBFDetails = $this->GetBFDetailsByClientID($GetClientId);
      if($GetBFDetails) {
        $GetCatalogueList = $this->GetCatalogueListDetailsByBFID($GetBFDetails, $requestparams);
        return $GetCatalogueList;
      } else {
        $responseResult = ['status' => 'error', 'status_message' => 'No record found.'];
        return $responseResult;
      }
    } else {
      $responseResult = ['status' => 'error', 'status_message' => 'No record found.'];
      return $responseResult;
    }
  }

  /**
   * Function :: Get briefing form details by client id.
   */
  public function GetCatalogueListDetailsByBFID($GetBFDetails, $requestparams) {
    # Get the DB Connection
		$db 	= \Drupal::database();
    $userID         = (isset($requestparams['userid']) && !empty($requestparams['userid']) && $requestparams['userid']!=null) ? $requestparams['userid']:null;
    $pageNo         = (isset($requestparams['pageno']) && !empty($requestparams['pageno']) && $requestparams['pageno']!=null) ? $requestparams['pageno']:null;
    $pageLimit      = (isset($requestparams['pagelimit']) && !empty($requestparams['pagelimit']) && $requestparams['pagelimit']!=null) ? $requestparams['pagelimit']:null;
    $catStatus      = (isset($requestparams['status']) && !empty($requestparams['status']) && $requestparams['status']!=null) ? $requestparams['status']:null;
    $clientName     = (isset($requestparams['client']) && !empty($requestparams['client']) && $requestparams['client']!=null) ? $requestparams['client']:null;
    $sortBy         = (isset($requestparams['sortby']) && !empty($requestparams['sortby']) && $requestparams['sortby']!=null) ? $requestparams['sortby']:null;
    $dueDate        = (isset($requestparams['duedate']) && !empty($requestparams['duedate']) && $requestparams['duedate']!=null) ? $requestparams['duedate']:null;
    $keywordsearch  = (isset($requestparams['keywordsearch']) && !empty($requestparams['keywordsearch']) && $requestparams['keywordsearch']!=null) ? urldecode($requestparams['keywordsearch']):null;
    $briefingformid = (isset($requestparams['briefingformid']) && !empty($requestparams['briefingformid']) && $requestparams['briefingformid']!=null) ? $requestparams['briefingformid']:null;
    $lastsevendate  = (isset($requestparams['lastsevendate']) && !empty($requestparams['lastsevendate']) && $requestparams['lastsevendate']!=null) ? $requestparams['lastsevendate']:null;
    $usertype       = (isset($requestparams['usertype']) && !empty($requestparams['usertype']) && $requestparams['usertype']!=null) ? $requestparams['usertype']:null;
    $catalogueType  = 'catalogue';
    if($sortBy==null || $sortBy == '' || $sortBy == 'Latest') {
      $recordSortBy = 'DESC';
    } else if($sortBy =='Oldest') {
      $recordSortBy = 'ASC';
    } else {
      $recordSortBy = 'DESC';
    }
    if($dueDate!=null) {
      $duedate1 = explode('-', $dueDate);
      $duedate2 = $duedate1[2].'-'.$duedate1[1].'-'.$duedate1[0];
    } else {
      $duedate2 = null;
    }
    try{
      // Select query. 
      $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfrefid.entity_id');
      $query->leftjoin('group_content_field_data', 'gcfd', 'gcfd.entity_id = nfd.nid');
      $query->leftjoin('groups_field_data', 'gfd', 'gfd.id = gcfd.gid');
      $query->leftjoin('node__field_catalogue_ref_name', 'nfcrn', 'nfcrn.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_name', 'nfcn', 'nfcn.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_image', 'nfcimg', 'nfcimg.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_status', 'nfcs', 'nfcs.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_start_date', 'nfcsd', 'nfcsd.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_finish_date', 'nfcfd', 'nfcfd.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_completion_date', 'nfccd', 'nfccd.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_prod_due_date', 'nfcpdd', 'nfcpdd.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_client_email', 'nfccmail', 'nfccmail.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_client_name', 'nfccname', 'nfccname.entity_id = nfbfrefid.entity_id');
      $query->leftjoin('node__field_catalogue_workflow', 'nfcw', 'nfcw.entity_id = nfbfrefid.entity_id');
      $query->addField('nfbfrefid', 'entity_id', 'catalogue_id');
      $query->addField('nfbfrefid', 'field_briefing_form_reference_id_target_id', 'field_briefing_form_reference_id');
      $query->addField('nfd', 'nid', 'node_id');
      $query->addField('nfd', 'type', 'node_type');
      $query->addField('nfd', 'title', 'node_title');
      $query->addField('nfd', 'created', 'nfd_created');
      $query->addField('nfd', 'changed', 'nfd_updated');
      $query->addField('gcfd', 'id', 'gcfd_id');
      $query->addField('gcfd', 'gid', 'gid');
      $query->addField('gcfd', 'entity_id', 'gcfd_entity_id');
      $query->addField('gcfd', 'label', 'gcfd_label');
      $query->addField('nfcrn', 'field_catalogue_ref_name_value', 'field_catalogue_ref_name');
      $query->addField('nfcn', 'field_catalogue_name_value', 'field_catalogue_name');
      $query->addField('nfcimg', 'field_catalogue_image_target_id', 'field_catalogue_image_fid');
      $query->addField('nfcimg', 'field_catalogue_image_alt', 'field_catalogue_image_alt');
      $query->addField('nfcimg', 'field_catalogue_image_title', 'field_catalogue_image_title');
      $query->addField('nfcs', 'field_catalogue_status_value', 'field_catalogue_status');
      $query->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount');
      $query->addField('nfcsd', 'field_catalogue_start_date_value', 'field_catalogue_start_date');
      $query->addField('nfcfd', 'field_catalogue_finish_date_value', 'field_catalogue_finish_date');
      $query->addField('nfccd', 'field_catalogue_completion_date_value', 'field_catalogue_completion_date');
      $query->addField('nfcpdd', 'field_catalogue_prod_due_date_value', 'field_catalogue_production_due_date');
      $query->addField('nfccmail', 'field_catalogue_client_email_value', 'catalogue_client_email');
      $query->addField('nfccname', 'field_catalogue_client_name_value', 'catalogue_client_name');
      $query->addField('nfcw', 'field_catalogue_workflow_value' , 'field_catalogue_workflow_status');
      $query->condition('nfd.type', $catalogueType, '=');
      $query->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $GetBFDetails, 'IN');
      // Check catalogue status.
      if($catStatus!=null && $catStatus!='all') {
        //$query->condition('nfcs.field_catalogue_status_value', $db->escapeLike($catStatus), '=');
        $orGroup = $query->orConditionGroup()
        ->condition('nfcs.field_catalogue_status_value', "%" . $db->escapeLike($catStatus) . "%" , 'LIKE')
        ->condition('nfcw.field_catalogue_workflow_value', "%" . $db->escapeLike($catStatus) . "%" , 'LIKE');
        // Add the group to the query.
        $query->condition($orGroup);
      }
      // Check catalogue client name.
      if($clientName!=null) {
        $query->condition('nfccname.field_catalogue_client_name_value', $db->escapeLike($clientName), '=');
      }
      // Check the catalogue due date.
      if($dueDate!=null && $duedate2!=null) {
        //$catalogueDueDate = date('Y-m-d', strtotime($dueDate));
        $startDate  = $duedate2.'T00:00:00';
        $endDate    = $duedate2.'T23:59:59';
        $a = array($startDate, $endDate);
        $query->condition('nfcfd.field_catalogue_finish_date_value', $a, 'BETWEEN');
        /*$orGroup3 = $query->andConditionGroup()
        ->condition('nfcfd.field_catalogue_finish_date_value', $a, 'BETWEEN')
        ->condition('nfcpdd.field_catalogue_prod_due_date_value', $a, 'BETWEEN');
        // Add the group to the query.
        $query->condition($orGroup3);*/
      }
      // Keyword search condition in catalogue name, client name.
      if($keywordsearch!=null) {
        // Create the orConditionGroup.
        $orGroup1 = $query->orConditionGroup()
        ->condition('nfd.title', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('gfd.label', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('nfcrn.field_catalogue_ref_name_value', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('nfcn.field_catalogue_name_value', "%" . $db->escapeLike($keywordsearch) . "%" , 'LIKE')
        ->condition('nfccname.field_catalogue_client_name_value', "%" . $db->escapeLike($keywordsearch) . "%", 'LIKE');
        // Add the group to the query.
        $query->condition($orGroup1);
      }
      // Briefing form id.
      if($briefingformid!=null) {
        $query->condition('nfbfrefid.entity_id', $db->escapeLike($briefingformid), '=');
      }
      // Last seven days.
      if($lastsevendate!=null) {
        $lastsevenLDate = strtotime(date('Y-m-d', strtotime($lastsevendate)).' 23:59:59');
        $lastsevenSDate = strtotime(date('Y-m-d', strtotime('-7 days')).' 00:00:00');
        $orGroup2 = $query->orConditionGroup()
        ->condition('nfd.created', array($lastsevenSDate, $lastsevenLDate), 'BETWEEN')
        ->condition('nfd.changed', array($lastsevenSDate, $lastsevenLDate), 'BETWEEN');
        // Add the group to the query.
        $query->condition($orGroup2);
      }
      $query->groupBy('nfbfrefid.entity_id');
      $query->orderBy('nfbfrefid.entity_id', $recordSortBy);
      $countQuery = $query;
      // Get query total records count.
      $countresults     = $countQuery->execute()->fetchAll();
      $GetTotalRecords  = count($countresults);
      // Page limit.
      $pagelimits       = (isset($pageLimit) || $pageLimit!='0') ? $pageLimit : 100;
      // Page number.
      $pagenos          = (isset($pageNo) || $pageNo!='0') ? $pageNo : 1;
      // Get page offset.
      $offset           = ($pagenos-1) * $pagelimits;
      // Get total pages.catalogue_approved
      $total_pages      = ceil($GetTotalRecords / $pagelimits);
      $query->range($offset, $pagelimits);
      // Get query result set.
      $results = $query->execute()->fetchAll();
      if($results) {
        $resultsJson[] = $results;
        foreach($results as $res) {
          $briefingform_id      = $res->field_briefing_form_reference_id;
          // Get designer details for total assigned page count and total completed page count.
          $GetDesignerArray     = $this->GetDesignerDetailsByParam($res->catalogue_id, $briefingform_id, $type = 'operator');
          // Get qc details for total assigned page count and total completed page count.
          $GetQCArray           = $this->GetQCDetailsByParam($res->catalogue_id, $briefingform_id, $type = 'supervisor');
          // Get Clipping region count array for catalogue page vise.
          $GetRegionCountArray  = $this->GetClippingRegionCountPageWiseByParams($res->catalogue_id, $res->field_catalogue_pagecount);
          // Get error edit count array for catalogue page vise.
          $GetErrorCountArray   = $this->GetErrorEditRegionCountPageWiseByParams($res->catalogue_id, $res->field_catalogue_pagecount);
          // Catalogue image.
          $field_catalogue_image_fid = !empty($res->field_catalogue_image_fid)?$res->field_catalogue_image_fid:null;
          if($field_catalogue_image_fid) {
            $image_path   = $this->GetNewFileURLByFID($field_catalogue_image_fid);
            if(isset($image_path) && $image_path!='') {
              $imagePath  = $image_path;
            } else {
              $imagePath  = '';
            }
          } else {
            $imagePath    = '';
          }
          $field_catalogue_workflow_status = '';
          $catWorkflow = $res->field_catalogue_workflow_status;
          $GetAllWorkFlow = $this->GetNDAllWorkflow();
          foreach($GetAllWorkFlow as $key=> $value) {
            if($catWorkflow == $key) {
              $field_catalogue_workflow_status = $value;
            }
          }
          $arrData[] = array(
            'field_catalogue_id'                  => $res->catalogue_id,
            'field_catalogue_title'               => $res->node_title,
            'field_catalogue_pagecount'           => $res->field_catalogue_pagecount,
            'field_catalogue_status'              => !empty($field_catalogue_workflow_status)?$field_catalogue_workflow_status:null, // need to change
            'field_catalogue_workflow_status'     => $res->field_catalogue_workflow_status,
            'field_briefingform_id'               => $res->field_briefing_form_reference_id,
            'field_catalogue_start_date'          => !empty($res->field_catalogue_start_date)?$res->field_catalogue_start_date:null,
            'field_catalogue_finish_date'         => !empty($res->field_catalogue_finish_date)?$res->field_catalogue_finish_date:null,
            'field_catalogue_completion_date'     => !empty($res->field_catalogue_completion_date)?$res->field_catalogue_completion_date:null,
            'field_catalogue_production_due_date' => !empty($res->field_catalogue_production_due_date)?$res->field_catalogue_production_due_date:null,
            'field_catalogue_image'               => $imagePath,
            'field_catalogue_client_name'         => !empty($res->catalogue_client_name)?$res->catalogue_client_name:null,
            'designer_array'                      => $GetDesignerArray,
            'qc_array'                            => $GetQCArray,
            'region_count_array'                  => $GetRegionCountArray,
            'error_count_array'                   => $GetErrorCountArray
          );
        }
        $return = array(
          'status'        => 'success',
          'total_records' => $GetTotalRecords,
          'total_pages'   => $total_pages,
          'num_results'   => $pagelimits,
          'current_pageno'=> $pagenos,
          'result_rows'   => $arrData,
        );
        \Drupal::logger('API--34')->notice('@requestparams ||  %resultsJson ||  %arrData ||  %GetBFDetails],', [
          '@requestparams' => json_encode($requestparams, true),
          '%resultsJson'   => json_encode($resultsJson, true),
          '%arrData'       => json_encode($arrData, true),
          '%GetBFDetails'  => json_encode($GetBFDetails, true)
        ]);
        return $return;
      } else {
        $resultsJson = array();
        $arrData = array();
        $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
        return $results;
      }
      \Drupal::logger('API--34')->notice('@requestparams ||  %resultsJson ||  %arrData ||  %GetBFDetails],', [
        '@requestparams' => json_encode($requestparams, true),
        '%resultsJson'   => json_encode($resultsJson, true),
        '%arrData'       => json_encode($arrData, true),
        '%GetBFDetails'  => json_encode($GetBFDetails, true),
      ]);
    } catch(\Exception $e){
      $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
      return $results;
    }
  }

  public function GetNDAllWorkflow() {
    $AllWorkflowStatus = WorkflowState::loadMultiple();
      $Workflow_array    = array();
      foreach ($AllWorkflowStatus as $state) {
        if($state->status) {
          $Workflow_array[$state->id()] = $state->label;
        }
      }
    /*$arrData = array();
    $states = WorkflowState::loadMultiple();
    //$states = Workflow::load('catalogue');
    foreach ($states as $state) {
      // Check the active status state and get the active status values only.
      if($state->status) {
        $arrData[] = array(
          $state->id() => $state->label,
        );
      }
    }*/
    return $Workflow_array;
  }

  /**
   * Get File Full URL from File Managed Table using FID.
   */
  public function GetNewFileURLByFID($fid) {
    $path = '';
    if($fid) {
      $file = File::load($fid);
      if(isset($file)) {
        if($file->getFileUri()) {
          $path = file_create_url($file->getFileUri());
        }
      }
    }
    $filePath = !empty($path)?$path:null;
    return $filePath;
  }

  /*public function GetBFDashboardDetailsByParams_old($userID, $userType) {
    // Get user details by user id.
    $GetUserDetails = $this->GetUserDetailsByUserId($userID);
    if($GetUserDetails) {
      $UserClientDetails = $GetUserDetails['user_details']['client_detail'];
      $GetClientId = $this->GetClientIdByDetails($UserClientDetails);
      // Get Briefing form details.
      $GetBFDetails = $this->GetBFDetailsByClientID($GetClientId);
      if($GetBFDetails) {
        $GetCatalogue = $this->GetCatalogueDetailsByBFID($GetBFDetails);
        if($GetCatalogue) {
          foreach($GetCatalogue as $catRecord) {
            $field_catalogue_id = $catRecord->catalogue_id;
            $field_catalogue_pagecount = $catRecord->field_catalogue_pagecount;
            if(!empty($field_catalogue_id)) {

              // Get designer details for total assigned page count and total completed page count.
              $GetDesignerArray    = $this->GetDesignerDetailsByParam($field_catalogue_id);
              // Get qc details for total assigned page count and total completed page count.
              $GetQCArray          = $this->GetQCDetailsByParam($field_catalogue_i);
              // Get Clipping region count array for catalogue page vise.
              $GetRegionCountArray  = $this->GetClippingRegionCountPageWiseByParams($field_catalogue_id, $field_catalogue_pagecount);
              // Get error edit count array for catalogue page vise.
              $GetErrorCountArray   = $this->GetErrorEditRegionCountPageWiseByParams($field_catalogue_id, $field_catalogue_pagecount);
              $arrData[] = array(
                'field_catalogue_id'        => $field_catalogue_id,
                'field_catalogue_pagecount' => $field_catalogue_pagecount,
                'field_briefingform_id'     => $catRecord->field_briefing_form_reference_id,
                'designer_array'            => $GetDesignerArray,
                'qc_array'                  => $GetQCArray,
                'region_count_array'        => $GetRegionCountArray,
                'error_count_array'         => $GetErrorCountArray,
              );
            }
          }
          return $arrData;
        } else {
          $responseResult = ['status' => 'error', 'status_message' => 'No record found.'];
          return $responseResult;
        }
      } else {
        $responseResult = ['status' => 'error', 'status_message' => 'No record found.'];
        return $responseResult;
      }
    } else {
      $responseResult = ['status' => 'error', 'status_message' => 'No record found.'];
      return $responseResult;
    }
  }*/

  /**
   * Function :: Get clipping region count page wise by params (catalogue id, catalogue page count)
   */
  public function GetClippingRegionCountPageWiseByParams($field_catalogue_id, $field_catalogue_pagecount) {
    for ($PageNumber = 1; $PageNumber <= $field_catalogue_pagecount; $PageNumber++) {
      // Select query.
      $query = \Drupal::database()->select('node__field_catalogue_reference', 'nfcr');
      $query->leftjoin('node__field_catalogue_page', 'nfcp', 'nfcp.entity_id = nfcr.entity_id');
      $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfcr.entity_id');
      $query->leftjoin('node__field_region_type', 'nfrt', 'nfrt.entity_id = nfcr.entity_id');
      $query->addField('nfcr', 'entity_id', 'region_id');
      $query->addField('nfcp', 'field_catalogue_page_value', 'catalogue_page_value');
      $query->addField('nfd', 'nid', 'nid');
      $query->addField('nfd', 'type', 'nfd_type');
      $query->addField('nfd', 'title', 'nfd_title');
      $query->addField('nfrt', 'field_region_type_value', 'region_type_name');
      $query->condition('nfd.type', 'region');
      $query->condition('nfcr.field_catalogue_reference_target_id', $field_catalogue_id);
      $query->condition('nfcp.field_catalogue_page_value', $PageNumber);
      $query->orderBy('nfcp.field_catalogue_page_value', 'ASC');
      //$query->groupBy('nfcr.entity_id');
      $results = $query->execute()->fetchAll();
      $arrData[$PageNumber] = count($results);
    }
    return $arrData;
  }

  /**
   * Function :: Get error edit region count page wise by params (catalogue id, catalogue page count)
   */
  public function GetErrorEditRegionCountPageWiseByParams($field_catalogue_id, $field_catalogue_pagecount) {

    for ($PageNumber = 1; $PageNumber <= $field_catalogue_pagecount; $PageNumber++) {
      // Select query.
      $query = \Drupal::database()->select('node__field_bfcatregion_catalogue_id', 'nfbfcat_catid');
      $query->leftjoin('node__field_bfcatregion_page_number', 'nfbfcat_pno', 'nfbfcat_pno.entity_id = nfbfcat_catid.entity_id');
      $query->addField('nfbfcat_catid', 'field_bfcatregion_catalogue_id_target_id', 'field_bfcatregion_catalogue_id');
      $query->addField('nfbfcat_pno', 'field_bfcatregion_page_number_value', 'field_bfcatregion_page_number');
      $query->condition('nfbfcat_catid.field_bfcatregion_catalogue_id_target_id', $field_catalogue_id);
      $query->condition('nfbfcat_pno.field_bfcatregion_page_number_value', $PageNumber);
      $query->orderBy('nfbfcat_pno.field_bfcatregion_page_number_value', 'ASC');
      //$query->groupBy('nfcr.entity_id');
      $results = $query->execute()->fetchAll();
      $arrData[$PageNumber] = count($results);
    }
    return $arrData;
  }

  /**
   * Function :: Get Designer details like total assigned count and completed count by catalogue id.
   */
  public function GetDesignerDetailsByParam($field_catalogue_id, $briefingform_id, $type) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catasur_catalogue_id', 'nfbfcatasur_cid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_briefingform_id', 'nfbfcatasur_bfid', 'nfbfcatasur_bfid.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigninguserid', 'nfbfcatasur_asuid', 'nfbfcatasur_asuid.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assign_userrole', 'nfbfcatasur_asurole', 'nfbfcatasur_asurole.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_pageno_range', 'nfbfcatasur_pr', 'nfbfcatasur_pr.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('users', 'us', 'us.uid = nfbfcatasur_asuid.field_bf_catasur_assigninguserid_target_id');
    $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfbfcatasur_asuid.field_bf_catasur_assigninguserid_target_id');
    $query->addField('nfbfcatasur_cid', 'field_bf_catasur_catalogue_id_target_id', 'field_bf_catasur_catalogue_id');
    $query->addField('nfbfcatasur_cid', 'entity_id', 'entity_id');
    $query->addField('nfbfcatasur_bfid', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_briefingform_id');
    $query->addField('nfbfcatasur_asuid', 'field_bf_catasur_assigninguserid_target_id', 'field_bf_catasur_assigninguserid');
    $query->addField('nfbfcatasur_asurole', 'field_bf_catasur_assign_userrole_value', 'field_bf_catasur_assign_userrole');
    $query->addField('nfbfcatasur_pr', 'field_bf_catasur_pageno_range_value', 'field_bf_catasur_pageno_range');
    $query->addField('ufd', 'uid', 'user_id');
    $query->addField('ufd', 'uid', 'user_id');
    $query->addField('ufd', 'name', 'user_name');
    $query->condition('nfbfcatasur_cid.field_bf_catasur_catalogue_id_target_id', $field_catalogue_id);
    $query->condition('nfbfcatasur_bfid.field_bf_catasur_briefingform_id_target_id', $briefingform_id);
    $query->condition('nfbfcatasur_asurole.field_bf_catasur_assign_userrole_value', $type);
    $query->orderBy('nfbfcatasur_cid.entity_id', 'ASC');
    $results = $query->execute()->fetchAll();
    if($results) {
      foreach($results as $res) {
        $userName   = $res->user_name;
        $shortName  = $this->GetShortUserName($userName);
        // Get designer assigned count.
        $GetDesignerAssignedCount   = $this->GetAssignedCountByCatalogueId($res->entity_id, $briefingform_id, $field_catalogue_id, $type = 'operator');
        // Get designer completed count.
        $GetDesignerCompletedCount  = $this->GetCompletedCountByCatalogueId($res->entity_id, $briefingform_id, $field_catalogue_id, $type = 'operator', $status = 'catalogue_completed');
        $arrData[] = array(
          'page_range'      => $res->field_bf_catasur_pageno_range,
          'user_fullname'   => $userName,
          'user_shortname'  => $shortName,
          $userName => array(
            'assigned'  => $GetDesignerAssignedCount,
            'completed' => $GetDesignerCompletedCount
          )
        );
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  /**
   * Function :: Get QC (supervisor) details like total assigned count and completed count by catalogue id.
   */
  public function GetQCDetailsByParam($field_catalogue_id, $briefingform_id, $type) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catasur_catalogue_id', 'nfbfcatasur_cid');
    $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_briefingform_id', 'nfbfcatasur_bfid', 'nfbfcatasur_bfid.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assigninguserid', 'nfbfcatasur_asuid', 'nfbfcatasur_asuid.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_assign_userrole', 'nfbfcatasur_asurole', 'nfbfcatasur_asurole.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('node__field_bf_catasur_pageno_range', 'nfbfcatasur_pr', 'nfbfcatasur_pr.entity_id = nfbfcatasur_cid.entity_id');
    $query->leftjoin('users', 'users', 'users.uid = nfbfcatasur_asuid.field_bf_catasur_assigninguserid_target_id');
    $query->leftjoin('users_field_data', 'ufd', 'ufd.uid = nfbfcatasur_asuid.field_bf_catasur_assigninguserid_target_id');
    $query->addField('nfbfcatasur_cid', 'field_bf_catasur_catalogue_id_target_id', 'field_bf_catasur_catalogue_id');
    $query->addField('nfbfcatasur_cid', 'entity_id', 'entity_id');
    $query->addField('nfbfcatasur_bfid', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_briefingform_id');
    $query->addField('nfbfcatasur_asuid', 'field_bf_catasur_assigninguserid_target_id', 'field_bf_catasur_assigninguserid');
    $query->addField('nfbfcatasur_asurole', 'field_bf_catasur_assign_userrole_value', 'field_bf_catasur_assign_userrole');
    $query->addField('nfbfcatasur_pr', 'field_bf_catasur_pageno_range_value', 'field_bf_catasur_pageno_range');
    $query->addField('ufd', 'uid', 'user_id');
    $query->addField('ufd', 'uid', 'user_id');
    $query->addField('ufd', 'name', 'user_name');
    $query->condition('nfbfcatasur_cid.field_bf_catasur_catalogue_id_target_id', $field_catalogue_id);
    $query->condition('nfbfcatasur_bfid.field_bf_catasur_briefingform_id_target_id', $briefingform_id);
    $query->condition('nfbfcatasur_asurole.field_bf_catasur_assign_userrole_value', $type);
    $query->orderBy('nfbfcatasur_cid.entity_id', 'ASC');
    $results = $query->execute()->fetchAll();
    if($results) {
      foreach($results as $res) {
        $userName   = $res->user_name;
        $shortName  = $this->GetShortUserName($userName);
        // Get qc assigned count.
        $GetQCAssignedCount   = $this->GetAssignedCountByCatalogueId($res->entity_id, $briefingform_id, $field_catalogue_id, $type = 'supervisor');
        // Get qc completed count.
        $GetQCCompletedCount  = $this->GetCompletedCountByCatalogueId($res->entity_id, $briefingform_id, $field_catalogue_id, $type = 'supervisor', $status = 'catalogue_completed');
        $arrData[] = array(
          'page_range'      => $res->field_bf_catasur_pageno_range,
          'user_fullname'   => $userName,
          'user_shortname'  => $shortName,
          $userName => array(
            'assigned'  => $GetQCAssignedCount,
            'completed' => $GetQCCompletedCount
          )
        );
      }
    } else {
      $arrData = array();
    }
    return $arrData;
    /*// Get qc assigned count.
    $GetQCAssignedCount   = $this->GetAssignedCountByCatalogueId($briefingform_id, $field_catalogue_id, $type = 'supervisor');
    $arrData['assigned']  = !empty($GetDesignerAssignedCount)?$GetDesignerAssignedCount:NULL;
    // Get qc completed count.
    $GetQCCompletedCount  = $this->GetCompletedCountByCatalogueId($briefingform_id, $field_catalogue_id, $type = 'supervisor', $status = 'catalogue_completed');
    $arrData['completed'] = !empty($GetDesignerCompletedCount)?$GetDesignerCompletedCount:NULL;
    return $arrData;*/
  }

  /**
   * Function :: Get Catalogue page assigned count details by catalogue id and login type (operator/supervisor).
   */
  public function GetAssignedCountByCatalogueId($entity_id, $briefingform_id, $field_catalogue_id, $type) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfau', 'nfbfau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcapn', 'nfbfcapn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
    $query->addField('nfbfcapn', 'field_bf_catau_page_number_value', 'field_bf_catau_page_number');
    $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'field_bf_catau_assigng_user_role');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'field_bf_catau_page_status');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $field_catalogue_id);
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $type);
    $query->condition('nfbfau.field_bfcatalogue_assigning_user_target_id', $entity_id);
    $query->orderBy('nfbfcapn.field_bf_catau_page_number_value', 'ASC');
    $results = $query->execute()->fetchAll();
    if($results) {
      $count_result = count($results);
    } else {
      $count_result = NULL;
    }
    return $count_result;
  }

  /**
   * Function :: Get Catalogue page completed count details by catalogue id and login type (operator/supervisor).
   */
  public function GetCompletedCountByCatalogueId($entity_id, $briefingform_id, $field_catalogue_id, $type, $status) {
    // Select query.
    $query = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'nfbfcpc');
    $query->leftjoin('node__field_bfcatalogue_assigning_user', 'nfbfau', 'nfbfau.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_number', 'nfbfcapn', 'nfbfcapn.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_assigng_user_role', 'nfbfcaur', 'nfbfcaur.entity_id = nfbfcpc.entity_id');
    $query->leftjoin('node__field_bf_catau_page_status', 'nfbfcps', 'nfbfcps.entity_id = nfbfcpc.entity_id');
    $query->addField('nfbfcpc', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
    $query->addField('nfbfcapn', 'field_bf_catau_page_number_value', 'field_bf_catau_page_number');
    $query->addField('nfbfcaur', 'field_bf_catau_assigng_user_role_value', 'field_bf_catau_assigng_user_role');
    $query->addField('nfbfcps', 'field_bf_catau_page_status_value', 'field_bf_catau_page_status');
    $query->condition('nfbfcpc.field_bf_catau_page_catalogue_target_id', $field_catalogue_id);
    $query->condition('nfbfcaur.field_bf_catau_assigng_user_role_value', $type);
    $query->condition('nfbfcps.field_bf_catau_page_status_value', $status);
    $query->condition('nfbfau.field_bfcatalogue_assigning_user_target_id', $entity_id);
    $query->orderBy('nfbfcapn.field_bf_catau_page_number_value', 'ASC');
    $results = $query->execute()->fetchAll();
    if($results) {
      $count_result = count($results);
    } else {
      $count_result = NULL;
    }
    return $count_result;
  }

  /**
   * Function :: Get catalogue details by briefing form id.
   */
  public function GetCatalogueDetailsByBFID($bfId) {
    // Select query.
    $query = \Drupal::database()->select('node__field_briefing_form_reference_id', 'nfbfrefid');
    $query->leftjoin('node__field_catalogue_pagecount', 'nfcpc', 'nfcpc.entity_id = nfbfrefid.entity_id');
    $query->addField('nfbfrefid', 'field_briefing_form_reference_id_target_id', 'field_briefing_form_reference_id');
    $query->addField('nfbfrefid', 'entity_id', 'catalogue_id');
    $query->addField('nfcpc', 'field_catalogue_pagecount_value', 'field_catalogue_pagecount');
    $query->condition('nfbfrefid.field_briefing_form_reference_id_target_id', $bfId);
    $result = $query->execute()->fetchAll();
    return $result;
  }

  /**
   * Function :: Get user client id by details.
   */
  public function GetClientIdByDetails($UserClientDetails) {
    if($UserClientDetails) {
      foreach($UserClientDetails as $res) {
        $ClientData[] = $res['client_id'];
      }
    } else {
      $ClientData = array();
    }
    return $ClientData;
  }

  /**
   * Function :: Get user details by user id.
   */
  public function GetUserDetailsByUserId($userID) {
    if($userID) {
      $user = User::load($userID);
      if(isset($user->user_picture->entity) && $user->user_picture->entity != '') {
        $user_picture = drupal_realpath($user->user_picture->entity->getFileUri());
      } else{
        $user_picture = '';
      }
      $token = base64_encode(random_bytes(32));
      // Get an array of organisation groups that this user is a member of.
      $organisations = rp_extras_get_organisations_for_user($user);
      if($organisations) {
        foreach ($organisations as $organisation) {
          // Get the clients belonging to this organisation.
          $clients = rp_extras_get_clients_for_organisation($organisation);
          foreach ($clients as $client) {
            if(isset($client->id->value) && !empty($client->id->value)) {
              $groups = \Drupal\group\Entity\Group::load($client->id->value);
              if ($groups->field_client_logo->entity != '') {
                $client_picture = drupal_realpath($groups->field_client_logo->entity->getFileUri());
              } else {
                $client_picture = '';
              }
              $client_detail[$client->id->value] = [
                'client_name'       => $client->label->value,
                'client_mail'       => $client->field_client_email->value,
                'client_logo'       => $client_picture,
                'client_id'         => $client->id->value,
                'client_ga_code'    => $groups->field_ga_code->value,
                'client_ga_view_id' => $groups->field_ga_view_id->value,
              ];
            }
          }
        }
      } else {
        //  $client_memberships = rp_extras_get_client_group_memberships_for_user($user);
        $client_memberships = rp_extras_get_clients_for_user($user);
          foreach ($client_memberships as $client_membership) {
          // Yes, so load the client group and get the id.
          $client_gid = $client_membership->id();
          if(isset($client_gid) && !empty($client_gid)) {
            $groups = \Drupal\group\Entity\Group::load($client_gid);
            if ($groups->field_client_logo->entity != '') {
              $client_picture = drupal_realpath($groups->field_client_logo->entity->getFileUri());
            } else {
              $client_picture = '';
            }
            $client_detail[$client_gid] = [
              'client_name'       => $groups->label->value,
              'client_mail'       => $groups->field_client_email->value,
              'client_logo'       => $client_picture,
              'client_id'         => $client_gid,
              'client_ga_code'    => $groups->field_ga_code->value,
              'client_ga_view_id' => $groups->field_ga_view_id->value,
            ];
          }
        }
      }
      if($user) {
        $response['user_details'] = [
          'uid'             => $user->id(),
          'uuid'            => $user->uuid(),
          'name'            => $user->getAccountName(),
          'email'           => $user->getEmail(),
          'roles'           => $user->getRoles(),
          'profile_picture' => $user_picture,
          'token'           => $token,
          'client_detail'   => $client_detail,
        ];
      } else {
        $response = array();
      }
      return $response;
    }
  }

  /**
   * Function :: Get briefing form details by client id.
   */
  public function GetBFDetailsByClientID($clientIDs) {
    // Select query for briefing form assets communication.
    $query = \Drupal::database()->select('node__field_briefing_form_client_id', 'nfbfcid');
    $query->leftjoin('node_field_data', 'nfd','nfd.nid = nfbfcid.entity_id');
    $query->leftjoin('node__field_briefing_catalogue_title', 'nfbfct', 'nfbfct.entity_id = nfbfcid.entity_id');
    $query->leftjoin('node__field_briefing_form_title', 'nfbft', 'nfbft.entity_id = nfbfcid.entity_id');
    $query->addField('nfbfcid', 'field_briefing_form_client_id_target_id', 'field_briefing_form_client_id');
    $query->addField('nfd', 'nid', 'briefing_form_id');
    $query->addField('nfbfct', 'field_briefing_catalogue_title_value', 'field_briefing_catalogue_title');
    $query->addField('nfbft', 'field_briefing_form_title_value', 'field_briefing_form_title');
    $query->condition('nfbfcid.field_briefing_form_client_id_target_id', $clientIDs, 'IN');
    $query->orderBy('nfbfcid.entity_id', 'ASC');
    $results = $query->execute()->fetchAll();
    if($results) {
      foreach($results as $res) {
        $arrData[] = $res->briefing_form_id;
      }
    } else {
      $arrData = array();
    }
    return $arrData;
  }

  public function GetShortUserName($username){
    if(!empty($username)){
      $SpaceUsername 	    = explode(' ', trim($username));
      $UnderscoreUsername = explode('_', trim($username));
      $HyphenUsername 	  = explode('-', trim($username));
      $user_Name          = '';
      // Space seperated.
      if(count($SpaceUsername)>1){
        $fname      = substr($SpaceUsername[0], 0, 1);
        $lname      = substr($SpaceUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // underscore seperated.
      if(count($UnderscoreUsername)>1){
        $fname      = substr($UnderscoreUsername[0], 0, 1);
        $lname      = substr($UnderscoreUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // Hyphen seperated.
      if(count($HyphenUsername)>1){
        $fname      = substr($HyphenUsername[0], 0, 1);
        $lname      = substr($HyphenUsername[1], 0, 1);
        $user_Name  = strtoupper($fname.$lname);
      }
      // Check Space, Underscore, Hyphen is empty. Given name is single word.
      if((count($SpaceUsername)==1) && (count($UnderscoreUsername)==1) && (count($HyphenUsername)==1)){
        $user_Name  = strtoupper(substr($username, 0, 2));
      }
      return $user_Name;
    } else {
      return null;
    }
  }
}
?>