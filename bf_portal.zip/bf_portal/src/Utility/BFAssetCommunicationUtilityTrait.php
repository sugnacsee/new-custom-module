<?php
namespace Drupal\bf_portal\Utility;

use Drupal\Component\Utility\UrlHelper;
use Drupal\file\Entity\File;
use Drupal\node\Entity\Node;
use Drupal\group\Entity\Group;
use Aws\S3\S3Client;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\bf_portal\Utility\BFTransactionHistoryUtilityTrait;

trait BFAssetCommunicationUtilityTrait
{
    use BFTransactionHistoryUtilityTrait;

    /**
    * Function to fetch data from assets communication content type tables.
    */
    public function GetBFAssetsCommunicationListByParams($arrData, $userID) {
        if(!empty($arrData)) {
            // S3 Bucket settings.
            $config = \Drupal::config('s3fs.settings');
            $s3config = $config->get();
            $domain = UrlHelper::filterBadProtocol($s3config['domain']);
            $file_path = '';
            // Assets Briefing Form Node Name.
            $nodeType = 'bf_assets_communication';
            foreach($arrData as $assetID){
                // Select Query.
                $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcomassid');
                $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_type_id', 'nfbfcomatid', 'nfbfcomatid.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_status', 'nfbfcomas', 'nfbfcomas.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_total_pages', 'nfbfcomatp', 'nfbfcomatp.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_error_pages', 'nfbfcomaep', 'nfbfcomaep.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_form_type', 'nfbfcomaft', 'nfbfcomaft.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcombfid', 'nfbfcombfid.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_comments', 'nfbfcomac', 'nfbfcomac.entity_id = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_assets_fid', 'nfbfcomafid', 'nfbfcomafid.entity_id = nfbfcomassid.entity_id');
                $query->addField('nfbfcomassid', 'entity_id', 'nfbfcomassid_entity_id');
                $query->addField('nfbfcomassid', 'field_bf_com_assets_id_target_id', 'field_bf_com_assets_id');
                $query->addField('nfd', 'title', 'node_title');
                $query->addField('nfd', 'uid', 'node_userid');
                $query->addField('nfd', 'nid', 'node_nid');
                $query->addField('nfbfcomatid', 'field_bf_com_assets_type_id_target_id', 'field_bf_com_assets_type_id');
                $query->addField('nfbfcomas', 'field_bf_com_assets_status_value', 'field_bf_com_assets_status');
                $query->addField('nfbfcomatp', 'field_bf_com_assets_total_pages_value', 'field_bf_com_assets_total_pages');
                $query->addField('nfbfcomaep', 'field_bf_com_assets_error_pages_value', 'field_bf_com_assets_error_pages');
                $query->addField('nfbfcomaft', 'field_bf_com_assets_form_type_value', 'field_bf_com_assets_form_type');
                $query->addField('nfbfcombfid', 'field_bf_com_briefingform_id_target_id', 'field_bf_com_briefingform_id');
                $query->addField('nfbfcomac', 'field_bf_com_assets_comments_value', 'field_bf_com_assets_comments');
                $query->addField('nfbfcomafid', 'field_bf_com_assets_fid_value', 'field_bf_com_assets_fid');
                $query->condition('nfd.type', $nodeType);
                //$query->condition('nfbfcomassid.field_bf_com_assets_id_target_id', $arrData, 'IN');
                $query->condition('nfbfcomassid.field_bf_com_assets_id_target_id', $assetID, '=');
                $query->orderBy('nfbfcomassid.entity_id', 'DESC');
                $query->range(0, 1);
                $results = $query->execute()->fetchAssoc();
                if(!empty( $results )){
                    // Get Asset type from id.
                    $getAssetType = $this->GetAssetsTypeById($results['field_bf_com_assets_type_id']);
                    //$field_assets_file = $this->GetFileURLByTargetId($res->field_bf_asset_id);
                    $field_bf_com_assets_fid = $results['field_bf_com_assets_fid'];
                    if($field_bf_com_assets_fid) {
                        $file 	        = File::load($field_bf_com_assets_fid);
                        $file_uri 	    = $file->getFileUri();
                        $path_explode   = explode("s3:/",$file_uri); 
                        if($path_explode[1] != ""){
                            $file_path      = str_replace('s3:/','https://' . $domain, $file_uri);
                        } else {
                            $file_path      = str_replace('private:/','https://' . $domain, $file_uri);
                        }
                    } else { 
                        $file_path = '';
                    }
                    $arrDatas[] = array(
                        'field_assets_com_nid'          => $results['nfbfcomassid_entity_id'],
                        'field_assets_com_bf_id'        => $results['field_bf_com_briefingform_id'],
                        'field_assets_com_assets_id'    => $results['field_bf_com_assets_id'],
                        'field_assets_com_form_type'    => $results['field_bf_com_assets_form_type'],
                        'field_assets_com_fid'          => $results['field_bf_com_assets_fid'],
                        'field_assets_com_file'         => $file_path,
                        'field_assets_com_type_id'      => $results['field_bf_com_assets_type_id'],
                        'field_assets_com_type_title'   => $getAssetType,
                        'field_assets_com_comments'     => $results['field_bf_com_assets_comments'],
                        'field_assets_com_total_page'   => $results['field_bf_com_assets_total_pages'],
                        'field_assets_com_error_page'   => $results['field_bf_com_assets_error_pages'],
                        'field_assets_com_status'       => $results['field_bf_com_assets_status'],
                    );
                }
            }
            return $arrDatas;
        } else {
            $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
            return $results;
        }
    }

    /**
    * Save:: Briefing Form API - Assets details to assets and communication table.
    */
    public function SaveBFAssetsCommunicationDetails($jsondata, $UUID) {
        //$userID = $this->GetUserIDByUUID($UUID);
        $userID = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
        // Step[1] - Insert Assets data in to Assets table.
        if(isset($jsondata['field_assets_com_comments']) && !empty($jsondata['field_assets_com_comments'])) {
           $notes = $jsondata['field_assets_com_comments'];
        } else { 
           $notes = null;
        }
        $node1_type = 'briefingform_assets';
        if(!empty($jsondata['field_assets_com_bf_id'])) {
            $bfId       = $jsondata['field_assets_com_bf_id'];
            $BFNode     = Node::load($bfId);
            $nodeTitle  = $BFNode->field_briefing_catalogue_title->value;
            $nodeTitle2 = $BFNode->field_briefing_catalogue_title->value;
        } else {
            $bfId       = NULL;
            $nodeTitle  = 'Briefing Form Assets';
            $nodeTitle2 = 'Briefing Form Assets Communication';
        }
        try{
            $BFAssetsCreatedData = array(
                'type'                        => $node1_type,
                'title'                       => $nodeTitle,
                'field_bf_form_type'          => !empty($jsondata['field_assets_com_form_type'])?$jsondata['field_assets_com_form_type']:null,
                'field_bf_asset_id'           => !empty($jsondata['field_assets_com_fid'])?$jsondata['field_assets_com_fid']:null,
                'field_bf_asset_type_id'      => !empty($jsondata['field_assets_com_type_id'])?$jsondata['field_assets_com_type_id']:null,
                'field_bf_asset_comments'     => $notes,
                'field_asset_briefingform_id' => !empty($jsondata['field_assets_com_bf_id'])?$jsondata['field_assets_com_bf_id']:null,
                'uid'                         => $userID
            );
            $node1 = Node::create($BFAssetsCreatedData);
            $node1->save();
            $asset_nid = $node1->id();
            if($asset_nid){
                // Step[2] - Insert Assets data in to Assets communication table.
                $node2_type  = 'bf_assets_communication';
                $BFAssetsComCreatedData = array(
                    'type'                              => $node2_type,
                    'title'                             => $nodeTitle2,
                    'field_bf_com_assets_form_type'     => !empty($jsondata['field_assets_com_form_type'])?$jsondata['field_assets_com_form_type']:null,
                    'field_bf_com_assets_fid'           => !empty($jsondata['field_assets_com_fid'])?$jsondata['field_assets_com_fid']:null,
                    'field_bf_com_assets_type_id'       => !empty($jsondata['field_assets_com_type_id'])?$jsondata['field_assets_com_type_id']:null,
                    'field_bf_com_assets_comments'      => $notes,
                    'field_bf_com_briefingform_id'      => !empty($jsondata['field_assets_com_bf_id'])?$jsondata['field_assets_com_bf_id']:null,
                    'field_bf_com_assets_id'            => $asset_nid,
                    'field_bf_com_assets_total_pages'   => !empty($jsondata['field_assets_com_total_page'])?$jsondata['field_assets_com_total_page']:null,
                    'field_bf_com_assets_error_pages'   => !empty($jsondata['field_assets_com_error_page'])?$jsondata['field_assets_com_error_page']:null,
                    'field_bf_com_assets_status'        => !empty($jsondata['field_assets_com_status'])?$jsondata['field_assets_com_status']:null,
                    'uid'                               => $userID
                );
                $node2 = Node::create($BFAssetsComCreatedData);
                $node2->save();
                $assetcom_nid = $node2->id();
                if($assetcom_nid){
                    $result = ['status' => 'success', 'status_message' => 'Briefing form assets details saved successfully.'];
                } else {
                    $result = ['status' => 'error', 'status_message' => 'Assets communication details not saved successfully. Please try after some times.'];
                }
                $BFAssetsCreatedData['bf_assets_nid']   = $asset_nid;
                $BFAssetsCreatedData['bf_assets_comm']  = $BFAssetsComCreatedData;
                $responseData                           = $BFAssetsCreatedData;
            } else {
                $result       = ['status' => 'error', 'status_message' => 'Assets details not saved successfully. Please try after some times.'];
                $responseData = $jsondata;
            }
        } catch (Exception $e) {
            $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
            $responseData = $jsondata;
        }
        // Add briefing form transaction history.
        $BFTransactionHistory = $this->BFTransactionHistory( $method = 'POST', $node1_type, $responseData, $userID, $result);
        return $result;
    }

    /**
    * Function Get User id by UUID.
    */
    public function GetUserIDByUUID($UUID) {
        $query 	= \Drupal::database()->select('users', 'U');
		$query->fields('U');
		$query->condition('U.uuid', $UUID, "=");
		$data 	 = $query->execute();
		$results = $data->fetchAssoc();
        if($results['uid']!='') {
            return $results['uid'];
        } else {
            return '0';
        }
    }

    /**
    * Save:: API 18 b) Briefing Form API - Assets details to assets and communication table.
    */
    public function PatchBFAssetsCommunicationDetails($jsondata, $UUID) {
        //$userID = $this->GetUserIDByUUID($UUID);
        // Step[1] - Insert Assets data in to Assets table.
        if(isset($jsondata['field_assets_com_comments']) && !empty($jsondata['field_assets_com_comments'])) {
           $notes = $jsondata['field_assets_com_comments'];
        } else { 
           $notes = null;
        }
        $userID                         = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
        $assetsNodeId                   = $jsondata['field_assets_com_assets_id'];
        $field_bf_form_type             = !empty($jsondata['field_assets_com_form_type'])?$jsondata['field_assets_com_form_type']:null;
        $field_assets_com_fid           = !empty($jsondata['field_assets_com_fid'])?$jsondata['field_assets_com_fid']:null;
        $field_assets_com_type_id       = !empty($jsondata['field_assets_com_type_id'])?$jsondata['field_assets_com_type_id']:null;
        $field_assets_com_bf_id         = !empty($jsondata['field_assets_com_bf_id'])?$jsondata['field_assets_com_bf_id']:null;
        $field_assets_com_total_page    = !empty($jsondata['field_assets_com_total_page'])?$jsondata['field_assets_com_total_page']:null;
        $field_assets_com_error_page    = !empty($jsondata['field_assets_com_error_page'])?$jsondata['field_assets_com_error_page']:null;
        $field_assets_com_status        = !empty($jsondata['field_assets_com_status'])?$jsondata['field_assets_com_status']:null;
        $node1_type                     = 'briefingform_assets';
        //$node1_title                    = 'Briefingform Assets';
        try{
            $node = Node::load($assetsNodeId);
            $nodeTitle = $node->getTitle();
            $catalogue_id = $node->field_bf_asset_catalogue_id->target_id;
            $node->set('type',$node1_type);
            $node->set('title', $nodeTitle);
            $node->set('field_bf_form_type', $field_bf_form_type);
            $node->set('field_bf_asset_id', $field_assets_com_fid);
            $node->set('field_bf_asset_type_id', $field_assets_com_type_id);
            $node->set('field_bf_asset_comments', $notes);
            $node->set('field_asset_briefingform_id', $field_assets_com_bf_id);
            $node->set('field_bf_asset_total_pages', $field_assets_com_total_page);
            $node->set('field_bf_asset_error_pages', $field_assets_com_error_page);
            $node->set('field_bf_asset_status', $field_assets_com_status);
            $node->set('uid', $userID);
            $update = $node->save();
            if($update){
                $BFAssetsUpdatedData = array(
                    'type'                        => $node1_type,
                    'title'                       => $nodeTitle,
                    'field_bf_form_type'          => $field_bf_form_type,
                    'field_bf_asset_id'           => $field_assets_com_fid,
                    'field_bf_asset_type_id'      => $field_assets_com_type_id,
                    'field_bf_asset_comments'     => $notes,
                    'field_asset_briefingform_id' => $field_assets_com_bf_id,
                    'field_bf_asset_total_pages'  => $field_assets_com_total_page,
                    'field_bf_asset_error_pages'  => $field_assets_com_error_page,
                    'field_bf_asset_status'       => $field_assets_com_status,
                    'uid'                         => $userID,
                    'bf_assets_nid'               => $assetsNodeId
                );
                // Step[2] - Insert Assets data in to Assets communication table.
                $node2_type  = 'bf_assets_communication';
                //$node2_title = 'Briefing Form Assets Communication';
                $BFAssetsComCreatedData = array(
                    'type'                              => $node2_type,
                    'title'                             => $nodeTitle,
                    'field_bf_com_assets_form_type'     => $field_bf_form_type,
                    'field_bf_com_assets_fid'           => $field_assets_com_fid,
                    'field_bf_com_assets_type_id'       => $field_assets_com_type_id,
                    'field_bf_com_assets_comments'      => $notes,
                    'field_bf_com_briefingform_id'      => $field_assets_com_bf_id,
                    'field_bf_com_assets_id'            => $assetsNodeId,
                    'field_bf_com_assets_total_pages'   => $field_assets_com_total_page,
                    'field_bf_com_assets_error_pages'   => $field_assets_com_error_page,
                    'field_bf_com_assets_status'        => $field_assets_com_status,
                    'uid'                               => $userID,
                );
                $node2 = Node::create($BFAssetsComCreatedData);
                $node2->save();
                $assetcom_nid = $node2->id();
                if($assetcom_nid) {
                    $BFAssetsComCreatedData['bf_com_assets_nid'] = $assetcom_nid;
                    if(!empty($catalogue_id) && (!empty($field_assets_com_status))) {
                        if(!empty($field_assets_com_status) && $field_assets_com_status == 'verified') {
                            $pageStatus = 'catalogue_created';
                        } else if(!empty($field_assets_com_status) && $field_assets_com_status == 'error') {
                            $pageStatus = 'catalogue_revision_required';
                        } else if(!empty($field_assets_com_status) && $field_assets_com_status == 'pending') {
                            $pageStatus = 'catalogue_job_review';
                        } else {
                            $pageStatus = '';
                        }
                        // Update the status to BF Catalogue Assigning User and BF Catalogue Assigning User Page Assignees.
                        // Change the date format from d-m-Y to Y-m-d.
                        $page_date = date('Y-m-d');
                        $query = \Drupal::database()->select('node__field_bf_catasur_catalogue_id', 'A');
                        $query->leftjoin('node__field_bf_catasur_briefingform_id', 'B', 'B.entity_id = A.entity_id');
                        $query->leftjoin('node_field_data', 'C', 'C.nid = A.entity_id');
                        $query->addField('A', 'field_bf_catasur_catalogue_id_target_id', 'field_bf_catasur_catalogue_id');
                        $query->addField('B', 'field_bf_catasur_briefingform_id_target_id', 'field_bf_catasur_briefingform_id');
                        $query->addField('C', 'nid', 'node_nid');
                        $query->condition('A.field_bf_catasur_catalogue_id_target_id', $catalogue_id);
                        $query->condition('B.field_bf_catasur_briefingform_id_target_id', $field_assets_com_bf_id);
                        $results = $query->execute()->fetchAll();
                        if(!empty($results)) {
                            foreach($results as $res) {
                                $query1 = \Drupal::database()->select('node__field_bf_catau_page_catalogue', 'A');
                                $query1->leftjoin('node__field_bfcatalogue_assigning_user', 'B', 'B.entity_id = A.entity_id');
                                $query1->leftjoin('node_field_data', 'C', 'C.nid = A.entity_id');
                                $query1->leftjoin('node__field_bf_catau_page_number', 'D', 'D.entity_id = A.entity_id');
                                $query1->leftjoin('node__field_bf_catau_page_userid', 'E', 'E.entity_id = A.entity_id');
                                $query1->addField('A', 'field_bf_catau_page_catalogue_target_id', 'field_bf_catau_page_catalogue');
                                $query1->addField('B', 'field_bfcatalogue_assigning_user_target_id', 'field_bfcatalogue_assigning_user');
                                $query1->addField('C', 'nid', 'node_nid');
                                $query1->addField('D', 'field_bf_catau_page_number_value', 'field_bf_catau_page_number');
                                $query1->addField('E', 'field_bf_catau_page_userid_target_id', 'field_bf_catau_page_userid');
                                $query1->condition('A.field_bf_catau_page_catalogue_target_id', $catalogue_id);
                                $query1->condition('B.field_bfcatalogue_assigning_user_target_id', $res->node_nid);
                                $results1 = $query1->execute()->fetchAll();
                                if(!empty($results1)) {
                                    foreach($results1 as $res1) {
                                       $field_bf_catau_page_nid = $res1->node_nid;
                                        // Update BF Catalogue Assigning User Page Assignees status and date.
                                        $node3 = Node::load($field_bf_catau_page_nid);
                                        $BFCatauNode = $node3;
                                        //$node->set('field_bf_catau_page_date', $page_date);
                                        if(!empty($pageStatus)) {
                                            $node3->set('field_bf_catau_page_status', $pageStatus);
                                            $page_Status = $pageStatus;
                                        } else {
                                            $node3->set('field_bf_catau_page_status', $node3->field_bf_catau_page_status->value);
                                            $page_Status = $BFCatauNode->field_bf_catau_page_status->value;
                                        }
                                        $updateNode1 = $node3->save(); 
                                        if($updateNode1) {
                                            $arrData = array(
                                                'type'                              => 'bf_cat_assigning_user_assignees',
                                                'title'                             => $nodeTitle,
                                                'field_bf_catau_page_catalogue'     => $catalogue_id,
                                                'field_bfcatalogue_assigning_user'  => $BFCatauNode->field_bfcatalogue_assigning_user->target_id,
                                                'field_bf_catau_page_userid'        => $BFCatauNode->field_bf_catau_page_userid->target_id,
                                                'field_bf_catau_page_number'        => $BFCatauNode->field_bf_catau_page_number->value,
                                                'field_bf_catau_page_date'          => $BFCatauNode->field_bf_catau_page_date->value,
                                                'field_bf_catau_page_status'        => $page_Status
                                            );
                                            // Save the POST request in BF Catalogue Assigning User Page Assignee's History content type.
                                            $jsonAssigneesHistoryData = json_encode($arrData, TRUE);
                                            $nodeCreate = Node::create(array(
                                                'type'                            => 'bf_cat_assuser_assignees_history',
                                                'title'                           => $nodeTitle,
                                                'field_bf_cataupageassignee_json' => $jsonAssigneesHistoryData,
                                                'field_bf_cataupageassignee_nid'  => $field_bf_catau_page_nid,
                                                'field_bf_cataupageassignee_date' => REQUEST_TIME,
                                                'field_bf_cataupageassigne_status' => $page_Status
                                            ));
                                            $SaveNode = $nodeCreate->save();
                                            //$createNodeId = $SaveNode->id();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // Update status to briefing form.
                    $bf_status = '';
                    switch ($field_assets_com_status) {
                        case "verified":
                            $bf_status = 'completed';
                          break;
                        case "error":
                            $bf_status = 'asset_required';
                          break;
                        case "pending":
                            $bf_status = 'in_process';
                          break;
                          case "submitted":
                              $bf_status = 'ready';
                            break;
                        default:
                            $bf_status = 'catalogue_created';
                    }
                    try {
                        // Load node by node id.
                        $BFNode = Node::load($field_assets_com_bf_id);
                        // update post status.
                        $BFNode->set('field_briefing_form_status', $bf_status);
                        $BFNodeUpdate = $BFNode->save();
                        if($BFNodeUpdate) {
                            $status_message = 'Update briefing form assets communication is updated successfully | field_assets_com_bf_id : '.$field_assets_com_bf_id.' | field_assets_com_status : '.$field_assets_com_status.' | bf_status : '.$bf_status;
                        } else {
                            $status_message = 'Update briefing form assets communication is not updated successfully | field_assets_com_bf_id : '.$field_assets_com_bf_id.' | field_assets_com_status : '.$field_assets_com_status.' | bf_status : '.$bf_status;
                        }
                        $response = ['status' => 'error', 'status_message' => $status_message];
                    } catch (Exception $e) {
                        $response = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
                    }
                    \Drupal::logger('BF-status-update')->notice('@jsondata ||  %response],', [
                        '@jsondata' => json_encode($jsondata),
                        '%response' => json_encode($response),
                    ]);
                    $BFAssetsUpdatedData['bf_assets_comm']  = $BFAssetsComCreatedData;
                    $result       = ['status' => 'success', 'status_message' => 'Briefing form assets details updated successfully.'];
                    $responseData = $BFAssetsUpdatedData;
                } else {
                    $result       = ['status' => 'error', 'status_message' => 'Assets communication details not updated successfully. Please try after some times.'];
                    $responseData = $jsondata;
                }
            } else {
                $result       = ['status' => 'error', 'status_message' => 'Assets details not updated successfully. Please try after some times.'];
                $responseData = $jsondata;
            }
        } catch (Exception $e) {
            $result       = ['status' => 'error', 'status_message' => json_decode($e->getMessage()),''];
            $responseData = $jsondata;
        }
        // Add briefing form transaction history.
        $BFTransactionHistory = $this->BFTransactionHistory( $method = 'PATCH', $node1_type, $responseData, $userID, $result);
        return $result;
    }

    /**
    * Save:: Briefing Form API - Assets details to assets and communication table.
    */
    public function DeleteBFAssetsCommunicationDetails($jsondata) {
        $userID = !empty($jsondata['field_user_id'])?$jsondata['field_user_id']:null;
        // Assets Briefing Form Node Name.
        $AssetComNodeType = 'bf_assets_communication';
        if(isset($jsondata['field_client_id']) && $jsondata['field_client_id']!='' && isset($jsondata['field_assets_com_bf_id']) && $jsondata['field_assets_com_bf_id']!='' && isset($jsondata['field_assets_com_assets_id']) && $jsondata['field_assets_com_assets_id']!='') {
            try{
                $field_assets_com_assets_id = $jsondata['field_assets_com_assets_id'];
                $field_assets_com_bf_id     = $jsondata['field_assets_com_bf_id'];
                // Assets ID Array
                $assetsID = array();
                // Assets Communication ID Array
                $assetsComID = array();
                // Select Query.
                $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcomassid');
                $query->leftjoin('node_field_data', 'nfd', 'nfd.nid = nfbfcomassid.entity_id');
                $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcombfid', 'nfbfcombfid.entity_id = nfbfcomassid.entity_id');
                $query->addField('nfbfcomassid', 'entity_id', 'nfbfcomassid_entity_id');
                $query->addField('nfbfcomassid', 'field_bf_com_assets_id_target_id', 'field_bf_com_assets_id');
                $query->addField('nfd', 'title', 'node_title');
                $query->addField('nfd', 'uid', 'node_userid');
                $query->addField('nfd', 'nid', 'node_nid');
                $query->addField('nfbfcombfid', 'field_bf_com_briefingform_id_target_id', 'field_bf_com_briefingform_id');
                $query->condition('nfd.type', $AssetComNodeType);
                $query->condition('nfbfcomassid.field_bf_com_assets_id_target_id', $field_assets_com_assets_id, '=');
                $query->condition('nfbfcombfid.field_bf_com_briefingform_id_target_id', $field_assets_com_bf_id, '=');
                $query->orderBy('nfbfcomassid.entity_id', 'DESC');
                $results = $query->execute()->fetchAll();
                if(!empty( $results )){
                    $i=0;
                    foreach($results as $res) {
                        $assetsID[$i]       = $res->field_bf_com_assets_id; // Assets content type node id
                        $assetsComID[$i]    = $res->node_nid; // Assets Communication content type node id.
                    }
                    // Delete assets communication content type data by node id.
                    $DeleteAssetsCom = $this->DeleteAssetsComByNodeId($assetsComID);
                    // Delete assets content type data by node id.
                    $DeleteAssets    = $this->DeleteAssetsByNodeId($assetsID);
                    $results = ['status' => 'success', 'status_message' => 'Briefing form assets details deleted successfully.'];
                    return $results;
                } else {
                    $results = ['status' => 'error', 'status_message' => 'No Record Found.'];   
                    return $results;
                }
            } catch(\Exception $e){
                $results = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
            }
        } else {
            $results = ['status' => 'error', 'status_message' => 'No Record Found.'];
        }
        $responseData = $jsondata;
        // Add briefing form transaction history.
        $BFTransactionHistory = $this->BFTransactionHistory( $method = 'Delete', $AssetComNodeType, $responseData, $userID, $results);
        return $results;
    }

  /**
  * Function for delete assets communication content type data by using param NId.
  **/
  public function DeleteAssetsComByNodeId($assetsComID) {
    foreach($assetsComID as $res) {
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($res);
        // Check if node exists with the given nid.
        if ($node) {
          $node->delete();
        }
    }
    return;
  }

  /**
  * Function for delete assets content type data by using param NId.
  **/
  public function DeleteAssetsByNodeId($assetsID) {
    foreach($assetsID as $res) {
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($res);
        // Check if node exists with the given nid.
        if ($node) {
          $node->delete();
        }
    }
    return;
  }

  /**
  * #17 a) Save:: Briefing Form API - Save catalogue processing failure status with appropriate assets details.
  */
  public function SaveBFCataloguePFSDetails($jsondata, $userID) {
    $node_type      = 'bf_assets_communication';
    $node_title     = 'Briefing Form Assets Communication';
    //Check the assets status by briefing form id and assets id.
    $checkBFAssets = $this->CheckAssetStatusById($jsondata['field_briefingform_id'], $jsondata['field_assets_id']);
    if($checkBFAssets) {
        $currentDate        = date('Y-m-d H:i:s');
        $briefingform_id    = $jsondata['field_briefingform_id'];
        $catalogue_id       = $jsondata['field_catalogue_id'];
        $assets_id          = $jsondata['field_assets_id'];
        $assets_form_type   = (isset($jsondata['field_assets_form_type']) && !empty($jsondata['field_assets_form_type']) && $jsondata['field_assets_form_type']!='null')?$jsondata['field_assets_form_type']:$checkBFAssets->field_bf_com_assets_form_type->value;
        $assets_new_fid     = (isset($jsondata['field_assets_new_assets_fid']) && !empty($jsondata['field_assets_new_assets_fid']) && $jsondata['field_assets_new_assets_fid']!='null')?$jsondata['field_assets_new_assets_fid']:$checkBFAssets->field_bf_com_assets_new_fid->value;
        $assets_type_id     = (isset($jsondata['field_assets_type_id']) && !empty($jsondata['field_assets_type_id']) && $jsondata['field_assets_type_id']!='null')?$jsondata['field_assets_type_id']:$checkBFAssets->field_bf_com_assets_type_id->target_id;
        $assets_comments    = (isset($jsondata['field_assets_error_notes']) && !empty($jsondata['field_assets_error_notes']) && $jsondata['field_assets_error_notes']!='null')?$jsondata['field_assets_error_notes']:$checkBFAssets->field_bf_com_assets_comments->value;
        $assets_total_pages = (isset($jsondata['field_assets_com_total_page']) && !empty($jsondata['field_assets_com_total_page']) && $jsondata['field_assets_com_total_page']!='null')?$jsondata['field_assets_com_total_page']:$checkBFAssets->field_bf_com_assets_total_pages->value;
        $assets_error_pages = (isset($jsondata['field_assets_error_page_number']) && !empty($jsondata['field_assets_error_page_number']) && $jsondata['field_assets_error_page_number']!='null')?$jsondata['field_assets_error_page_number']:$checkBFAssets->field_bf_com_assets_error_pages->value;
        $assets_status      = (isset($jsondata['field_assets_error_status']) && !empty($jsondata['field_assets_error_status']) && $jsondata['field_assets_error_status']!='null')?$jsondata['field_assets_error_status']:$checkBFAssets->field_bf_com_assets_status->value;
        $assets_error_date  = (isset($jsondata['field_assets_error_reported_date']) && !empty($jsondata['field_assets_error_reported_date']) && $jsondata['field_assets_error_reported_date']!='null')?$jsondata['field_assets_error_reported_date']:$currentDate;
        $assets_reported_uid= (isset($jsondata['field_assets_error_reported_userid']) && !empty($jsondata['field_assets_error_reported_userid']) && $jsondata['field_assets_error_reported_userid']!='null')?$jsondata['field_assets_error_reported_userid']:'0';
        $new_assets_details = (isset($jsondata['field_assets_new_assets_details']) && !empty($jsondata['field_assets_new_assets_details']) && $jsondata['field_assets_new_assets_details']!='null')?$jsondata['field_assets_new_assets_details']:'';
        if(!empty($assets_new_fid)) {
            $assets_fid     = $assets_new_fid;
        } else {
            $assets_fid     = $checkBFAssets->field_bf_com_assets_fid->value;
        }
        try {
            $asset_node     = Node::load($assets_id);
            $nodeTitle      = $asset_node->getTitle();
            $asset_title    = (isset($nodeTitle) && !empty($nodeTitle) && $nodeTitle!='null')?$nodeTitle:'';
            $errorDate      = date('Y-m-d', strtotime($assets_error_date)); 
            $errorTime      = date('H:i:s', strtotime($assets_error_date)); 
            $errorDateTime  = $errorDate.'T'.$errorTime;
            $BFAssetsComCreatedData = array(
                'type'                              => $node_type,
                'title'                             => $asset_title,
                'field_bf_com_assets_form_type'     => $assets_form_type,
                'field_bf_com_assets_fid'           => $assets_fid,
                'field_bf_com_assets_type_id'       => $assets_type_id,
                'field_bf_com_assets_comments'      => $assets_comments,
                'field_bf_com_briefingform_id'      => $briefingform_id,
                'field_bf_com_assets_id'            => $assets_id,
                'field_bf_com_assets_total_pages'   => $assets_total_pages,
                'field_bf_com_assets_error_pages'   => $assets_error_pages,
                'field_bf_com_assets_status'        => $assets_status,
                'field_bf_com_assets_error_date'    => $errorDateTime,
                'field_bf_com_assets_reported_uid'  => $assets_reported_uid,
                'field_bf_com_assets_new_fid'       => $assets_new_fid,
                'field_bf_com_new_assets_details'   => $new_assets_details,
                'uid'                               => $userID,
            );
            $node = Node::create($BFAssetsComCreatedData);
            $node->save();
            $assetcom_nid = $node->id();
            if($assetcom_nid) {
                $BFAssetsComCreatedData['bf_com_assets_nid'] = $assetcom_nid;
                // Check the new asset fid is available or not. If the value is available means we have to update the fid to assets main table.
                if($assets_new_fid) {
                    $asset_node->set('field_bf_asset_status', $assets_status);
                    $asset_node->set('field_bf_asset_id', $assets_new_fid);
                    $asset_node->set('field_bf_asset_comments', $assets_comments);
                    $update_node = $asset_node->save();
                    if($update_node) {
                        // Get briefing form details by node id.
                        $getbriefingform = Node::load($briefingform_id);
                        if(isset($getbriefingform) && $getbriefingform->field_briefing_form_client_id->target_id!='') {
                            $bf_client_id = $getbriefingform->field_briefing_form_client_id->target_id;
                        } else {
                            $bf_client_id = null;
                        }
                        /**********************************************************/
                        /******* Sending Mail using CURL Function - Start *********/
                        /**********************************************************/
                        header("Content-Type: text/json;");
                        $host = \Drupal::request()->getSchemeAndHttpHost();
                        // Curl function.
                        $url = $host.'/briefingform/api/bfpost-mail';
                        $arrayAssets[] = array(
                            'field_assets_id' => $assets_id,
                            'field_assets_error_notes' => $new_assets_details
                        );
                        $data = array(
                            "field_client_id" => $bf_client_id,
                            "field_mail_type" => "2",
                            "field_briefingform_id" => $briefingform_id,
                            "field_assets"=> $arrayAssets
                        );
                        $data_string = json_encode($data);
                        $header = array("Content-Type: application/json");
                        $curl   = curl_init();
                        curl_setopt_array($curl, array(
                            CURLOPT_URL => $url,
                            CURLOPT_HTTPHEADER => $header,
                            CURLOPT_SSL_VERIFYPEER => 0,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $data_string
                        ));
                        $response = curl_exec($curl);
		                curl_close($curl);
                        /**********************************************************/
                        /******** Sending Mail using CURL Function - End **********/
                        /**********************************************************/
                        $response = ['status' => 'success', 'status_message' => 'Catalogue process failure assets details saved successfully.'];
                    } else {
                        $response = ['status' => 'error', 'status_message' => 'Catalogue process failure assets details are not saved successfully.'];
                    }
                    $responseData = $BFAssetsComCreatedData;
                    // Calling catalogue automation API concurrent process.
                    $assetsnodeId[] = $assets_id;
                    $AutomationCURLProcess = $this->BriefingFormCatalogueAutomationCURLProcess($briefingform_id, $assetsnodeId);
                } else {
                    $asset_node->set('field_bf_asset_status', $assets_status);
                    $update_node  = $asset_node->save();
                    $response     = ['status' => 'success', 'status_message' => 'Catalogue process failure assets details saved successfully.'];
                    $responseData = $jsondata;
                }
            } else {
                $response     = ['status' => 'error', 'status_message' => 'Catalogue process failure assets details are not saved successfully.'];
                $responseData = $jsondata;
            }
        } catch(\Exception $e){
            $response     = ['status' => ((int) $e->getCode() > 0 ? (int) $e->getCode() : 400), 'status_message' => (!empty($e->getMessage()) ? json_decode($e->getMessage()) : 'Bad Request')];
            $responseData = $jsondata;
        }
    } else {
        $response     = ['status' => 'error', 'status_message' => 'Catalogue assets not in error status. Please check the data.'];
        $responseData = $jsondata;
    }
    // Add briefing form transaction history.
    $BFTransactionHistory = $this->BFTransactionHistory( $method = 'POST', $node_type, $responseData, $userID, $response);
    return $response;
  }

  /**
  * Check the assets status by briefing form id and assets id.
  */
  public function CheckAssetStatusById($briefingformID, $assetsID) {
    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcomaid');
    $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcombfid', 'nfbfcombfid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_status', 'nfbfcomas', 'nfbfcomas.entity_id = nfbfcomaid.entity_id');
    $query->addField('nfbfcomaid', 'entity_id', 'entity_id');
    $query->addField('nfbfcomaid', 'field_bf_com_assets_id_target_id', 'bf_assets_id');
    $query->addField('nfbfcombfid', 'field_bf_com_briefingform_id_target_id', 'briefingform_id');
    $query->addField('nfbfcomas', 'field_bf_com_assets_status_value', 'bf_assets_status');
    $query->condition('nfbfcomaid.field_bf_com_assets_id_target_id', $assetsID);
    $query->condition('nfbfcombfid.field_bf_com_briefingform_id_target_id', $briefingformID);
    $query->condition('nfbfcomas.field_bf_com_assets_status_value', 'error');
    $query->orderBy('nfbfcomaid.field_bf_com_assets_id_target_id', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    if(!empty($results)){
        $nid  = $results['entity_id'];
        $node = \Drupal\node\Entity\Node::load($nid);
        return $node;        
    } else {
        return false;
    }
  }

  /**
  * #17 b) Get : API for Retrieving catalogue processing failure status with appropriate assets details.
  */
  public function GetBFCataloguePFSDetails($briefingformID, $assetsID) {
    // S3 Bucket settings.
    $config = \Drupal::config('s3fs.settings');
    $s3config = $config->get();
    $domain = UrlHelper::filterBadProtocol($s3config['domain']);
    $file_path = '';
    $file_path1 = '';
    // Get Assets details by node load.
    $node = \Drupal\node\Entity\Node::load($assetsID);
    if($node) {
        $briefingform_id= $node->field_asset_briefingform_id->target_id;
        $asset_id       = $node->id();
        // Assets file.
        $field_asset_fid = $node->field_bf_asset_id->value;
        if($field_asset_fid) {
            $file 	        = File::load($field_asset_fid);
            $file_uri 	    = $file->getFileUri();
            $path_explode   = explode("s3:/",$file_uri); 
            if($path_explode[1] != ""){
                $file_path      = str_replace('s3:/','https://' . $domain, $file_uri);
            } else {
                $file_path      = str_replace('private:/','https://' . $domain, $file_uri);
            }
        } else { 
            $file_path = '';
        }
        // Get assets other details from assets communication content type.
        $getbfassetcom  = $this->GetBFAssetsComDetailByParam($briefingform_id, $asset_id);
        // Get new assets file.
        $field_asset_new_fid = $getbfassetcom['bf_assets_new_fid'];
        if($field_asset_new_fid) {
            $file1 	        = File::load($field_asset_new_fid);
            $file_uri1 	    = $file1->getFileUri();
            $path_explode1   = explode("s3:/",$file_uri1);
            if($path_explode1[1] != ""){
                $file_path1      = str_replace('s3:/','https://' . $domain, $file_uri1);
            } else {
                $file_path1      = str_replace('private:/','https://' . $domain, $file_uri1);
            }
        } else { 
            $file_path1 = '';
        }
        $arrData[] = array(
            'field_briefingform_id'                 => $briefingform_id,
            'field_asset_comments'                  => $node->field_bf_asset_comments->value,
            'field_asset_id'                        => $node->id(),
            'field_asset_fid'                       => $node->field_bf_asset_id->value,
            'field_asset_file'                      => $file_path,
            'field_asset_type_id'                   => $node->field_bf_asset_type_id->target_id,
            'field_asset_type_value'                => !empty($getbfassetcom['bf_assets_type_value'])?$getbfassetcom['bf_assets_type_value']:null,
            'field_assets_form_type'                => $node->field_bf_form_type->value,
            'field_assets_error_status'             => !empty($getbfassetcom['bf_assets_status'])?$getbfassetcom['bf_assets_status']:null,
            'field_assets_new_assets_fid'           => !empty($getbfassetcom['bf_assets_new_fid'])?$getbfassetcom['bf_assets_new_fid']:null,
            'field_assets_new_assets_file'          => $file_path1,
            'field_assets_new_assets_details'       => !empty($getbfassetcom['bf_assets_new_details'])?$getbfassetcom['bf_assets_new_details']:null,
            'field_assets_total_pages'              => !empty($getbfassetcom['bf_assets_total_pages'])?$getbfassetcom['bf_assets_total_pages']:null,
            'field_assets_error_reported_userid'    => !empty($getbfassetcom['bf_assets_reported_userid'])?$getbfassetcom['bf_assets_reported_userid']:null,
            'field_assets_error_reported_date'      => !empty($getbfassetcom['bf_assets_error_date'])?$getbfassetcom['bf_assets_error_date']:null,
            'field_assets_error_page_number'        => !empty($getbfassetcom['bf_assets_error_page'])?$getbfassetcom['bf_assets_error_page']:null
        );
        return $arrData;
    } else {
        return false;
    }
  }

  public function GetBFAssetsComDetailByParam($briefingformID, $assetsID) {

    $query = \Drupal::database()->select('node__field_bf_com_assets_id', 'nfbfcomaid');
    $query->leftjoin('node__field_bf_com_briefingform_id', 'nfbfcombfid', 'nfbfcombfid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_status', 'nfbfcomas', 'nfbfcomas.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_error_date', 'nfbfcomaed', 'nfbfcomaed.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_reported_uid', 'nfbfcomaruid', 'nfbfcomaruid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_new_fid', 'nfbfcomanfid', 'nfbfcomanfid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_comments', 'nfbfcomacmt', 'nfbfcomacmt.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_error_pages', 'nfbfcomaep', 'nfbfcomaep.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_fid', 'nfbfcomafid', 'nfbfcomafid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_form_type', 'nfbfcomaft', 'nfbfcomaft.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_total_pages', 'nfbfcomatotp', 'nfbfcomatotp.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_assets_type_id', 'nfbfcomatypid', 'nfbfcomatypid.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_bf_com_new_assets_details', 'nfbfcomnad', 'nfbfcomnad.entity_id = nfbfcomaid.entity_id');
    $query->leftjoin('node__field_briefing_form_assets_type', 'nfbfatpmaster', 'nfbfatpmaster.entity_id = nfbfcomatypid.field_bf_com_assets_type_id_target_id');
    $query->addField('nfbfcomaid', 'entity_id', 'entity_id');
    $query->addField('nfbfcomaid', 'field_bf_com_assets_id_target_id', 'bf_assets_id');
    $query->addField('nfbfcombfid', 'field_bf_com_briefingform_id_target_id', 'briefingform_id');
    $query->addField('nfbfcomas', 'field_bf_com_assets_status_value', 'bf_assets_status');
    $query->addField('nfbfcomaed', 'field_bf_com_assets_error_date_value', 'bf_assets_error_date');
    $query->addField('nfbfcomaruid', 'field_bf_com_assets_reported_uid_value', 'bf_assets_reported_userid');
    $query->addField('nfbfcomanfid', 'field_bf_com_assets_new_fid_value', 'bf_assets_new_fid');
    $query->addField('nfbfcomacmt', 'field_bf_com_assets_comments_value', 'bf_assets_comments');
    $query->addField('nfbfcomaep', 'field_bf_com_assets_error_pages_value', 'bf_assets_error_page');
    $query->addField('nfbfcomafid', 'field_bf_com_assets_fid_value', 'bf_assets_fid');
    $query->addField('nfbfcomaft', 'field_bf_com_assets_form_type_value', 'bf_assets_form_type');
    $query->addField('nfbfcomatotp', 'field_bf_com_assets_total_pages_value', 'bf_assets_total_pages');
    $query->addField('nfbfcomatypid', 'field_bf_com_assets_type_id_target_id', 'bf_assets_type_id');
    $query->addField('nfbfcomnad', 'field_bf_com_new_assets_details_value', 'bf_assets_new_details');
    $query->addField('nfbfatpmaster', 'field_briefing_form_assets_type_value', 'bf_assets_type_value');
    $query->condition('nfbfcomaid.field_bf_com_assets_id_target_id', $assetsID);
    $query->condition('nfbfcombfid.field_bf_com_briefingform_id_target_id', $briefingformID);
    $query->orderBy('nfbfcomaid.entity_id', 'DESC');
    $query->range(0, 1);
    $results = $query->execute()->fetchAssoc();
    if($results) {
        return $results;
    } else {
        return false;
    }
  }

  /**
   * Briefing form - save all type of transaction history.
   */
  /*public function BFTransactionHistory($method, $type, $responseData, $InsUserId, $result) {
    $encodeData = json_encode($responseData);
    if($method=='POST') {
      $createdBy    = $InsUserId;
      $createdDate  = date('Y-m-d H:i:s');
      $updatedBy    = null;
      $updatedDate  = null;
    } else {
      $createdBy    = null;
      $createdDate  = null;
      $updatedBy    = $InsUserId;
      $updatedDate  = date('Y-m-d H:i:s');
    }
    try{
      $insertQry = \Drupal::database()->insert('briefingform_transaction_history')
            ->fields([
              'bf_th_method'        => $method,
              'bf_th_type_name'     => $type,
              'bf_th_content'       => $encodeData,
              'bf_th_created_by'    => $createdBy,
              'bf_th_created_date'  => $createdDate,
              'bf_th_updated_by'    => $updatedBy,
              'bf_th_updated_date'  => $updatedDate,
              'bf_th_status_msg'    => $result['status_message'],
              'bf_th_status'        => $result['status']
            ])->execute();
      return $insertQry;
    } catch (Exception $e) {
      return $e;
    }
  }*/
}
?>